from django.apps import AppConfig


class EmployeeManagementAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Employee_Management_APP'
